const fs = require('fs');

fs.unlink('texto.txt', function (err) {
  if (err) throw err;
  console.log('File deleted!');
});