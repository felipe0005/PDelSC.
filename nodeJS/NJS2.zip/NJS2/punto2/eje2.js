import {createServer} from "node:http";
import fs from 'fs';

fs.appendFile('nuevoTexto.txt', 'Hello content!', function (err) {
  if (err) throw err;
  console.log('Saved!');
});
