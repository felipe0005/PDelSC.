import {createServer} from "node:http";
import fs from 'fs';


const server = createServer((req, res) => {
  fs.readFile('texto.txt', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Error al leer el archivo');
      return;
    }

    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write(data);
    res.end();
  });
});

server.listen(8080, () => {
  console.log('Servidor corriendo en http://localhost:8080');
});