// se crear la funcion tiempo
export function tiempo(a){

    return a/60;

}

// se crea la funcion temperatura
export function temperatura(b){

    return (b - 32)/1.8

}

// se crea la funcion potenciacion
export function potenciacion(a,b){

    return a**b

}