import {createServer} from "node:http";
//importo la funcion temperatura del modulo Modulo.js
import { temperatura } from "./modulo/funciones.js";

//inicializo la variable farenheit y imprimo el resultado 
const server = createServer((req,res) => {
    res.writeHead(200, { 'Content-Type': 'text/html'});
    res.end(
        `<p>La convercion de grados celesius a farenheit va a ser: <p>
        ${temperatura(40)}
        `
        );
});

server.listen(3000, '127.0.0.1',() => {
    console.log('listening on http://127.0.0.1:3000')
});