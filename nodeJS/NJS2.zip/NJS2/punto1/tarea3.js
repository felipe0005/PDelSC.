// import la funcion potenciacion del modulo modulo.js
import { potenciacion } from "./modulo/funciones";

const server = createServer((req,res) => {
    res.writeHead(200, { 'Content-Type': 'text/html'});
    res.end(
        `<p>la potencia de 4**6 es: <p>
        ${potenciacion(4,6)}
        `
        );
});

server.listen(3000, '127.0.0.1',() => {
    console.log('listening on http://127.0.0.1:3000')
});