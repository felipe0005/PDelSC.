import {createServer} from "node:http";
//importo el modulo del archivo Modulo.js
import { tiempo } from "./modulo/funciones.js";

//inicializo la variable horas y imprimo el resultado
const server = createServer((req,res) => {
    res.writeHead(200, { 'Content-Type': 'text/html'});
    res.end(
        `<p>El resultado de la convercion de Horas a minutos es: <p>
        ${tiempo(30)}
        `
        );
});

server.listen(3000, '127.0.0.1',() => {
    console.log('listening on http://127.0.0.1:3000')
});