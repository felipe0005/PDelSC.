function sumar(a,b){
    return a + b;

}

function restar(a,b){
    return a - b;
    
}

function multi(a,b){
    return a * b;
    
}

function division(a,b){
    return a / b;
    
}

console.log(sumar(4,5));
console.log(restar(4,5));
console.log(multi(4,5));
console.log(division(4,5));
