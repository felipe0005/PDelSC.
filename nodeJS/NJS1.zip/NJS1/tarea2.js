const a = 20;
const b = 13;

const suma = a + b;
const resta = a - b;
const multiplicacion = a*b;
const division = a/b;

console.log("La suma es: " + suma);
console.log("La resta es: " + resta);
console.log("La multiplicacion es: " + multiplicacion);
console.log("La division es: " + division);
