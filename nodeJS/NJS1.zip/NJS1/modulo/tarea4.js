import{sumar,restar,multi,division} from "./calculos.js"

console.log("La suma es: " + sumar(4,7));
console.log("La resta es: " + restar(2,5));
console.log("la multiplicacion es: " + multi(8,5));
console.log("La division es: " + division(4,10));
