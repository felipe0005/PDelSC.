export function sumar(a,b){
    return a + b;

}

export function restar(a,b){
    return a - b;
    
}

export function multi(a,b){
    return a * b;
    
}

export function division(a,b){
    return a / b;
    
}
