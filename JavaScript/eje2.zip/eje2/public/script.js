const tel = document.getElementById('phone')
const plata = document.getElementById('money')
const objeto = document.getElementById('item')
const mail = document.getElementById('email')
const form = document.getElementById('form')
const parra = document.getElementById('warning')
const lista = document.getElementById('lista');


form.addEventListener("submit", async e => {
  e.preventDefault();
  let warnings = "";
  let entrar = false;
  let regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (tel.value.length < 4) {
    warnings += `El telefono es invalido <br>`;
    entrar = true;
  }
  if (!regexEmail.test(mail.value)) {
    warnings += `El email es invalido <br>`;
    entrar = true;
  }
  if (objeto.value.length < 4) {
    warnings += `El objeto es invalido <br>`;
    entrar = true;
  }
  if (plata.value.length < 2) {
    warnings += `El monto es invalido <br>`;
    entrar = true;
  }
  if (entrar == true) {
    parra.innerHTML = warnings
  }
  else {
    parra.innerHTML = "enviado"
    // Enviar datos al backend
    await sendData({
      telefono: tel.value,
      monto: plata.value,
      objeto: objeto.value,
      email: mail.value
    });
    await fetchData(); // Actualizar la lista
    // Limpiar campos
    tel.value = "";
    plata.value = "";
    objeto.value = "";
    mail.value = "";
  }
})


async function fetchData() {
  try {
    const response = await fetch("/objetos", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "x-api-key":
          "b9e5cdb7a9fc4e10b7c6b8a34ff5e2d8a4c9f18ed124eab5b02f4dd3e1cba7e1",
      },
    });
    if (response.ok) {
      const data = await response.json();
      lista.innerHTML = data
        .map(
          (item) =>
            `<li class="border-b-2 border-violet-300 px-6 py-2 text-center w-full">${item.telefono} - ${item.monto} - ${item.objeto} - ${item.email}</li>`
        )
        .join("");
    }
  } catch (err) {
    console.log(err);
  }
}

async function sendData(data) {
  try {
    await fetch("/objetos", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key":
          "b9e5cdb7a9fc4e10b7c6b8a34ff5e2d8a4c9f18ed124eab5b02f4dd3e1cba7e1",
      },
      body: JSON.stringify(data),
    });
  } catch (err) {
    console.log(err);
  }
}

// Al cargar la página, mostrar la lista
fetchData();