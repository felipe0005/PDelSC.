const form = document.getElementById('userForm');
const mensaje = document.getElementById('mensaje');
const listaUsuarios = document.getElementById('listaUsuarios');
let usuarios = [];

form.addEventListener('submit', function(e) {
  e.preventDefault();

  const name = document.getElementById('usr').value.trim();
  const pass = document.getElementById('pass').value.trim();


  if (name.length < 10 || pass.length < 10 ){
    mostrarMensaje('Por favor, rellena correctamente todos los campos.', false);
    return;
  }


  usuarios.push({name, pass});
  mostrarMensaje('Usuario guardado correctamente.', true);
  actualizarLista();
  form.reset(); 
});

function mostrarMensaje(texto, exito) {
  mensaje.textContent = texto;
  mensaje.className = exito ? 'ok' : 'error';
}

function actualizarLista() {
  listaUsuarios.innerHTML = '';
  usuarios.forEach(user => {
    const li = document.createElement('li');
    li.textContent = `${user.name} ${user.pass}`;
    listaUsuarios.appendChild(li);
  });
}
